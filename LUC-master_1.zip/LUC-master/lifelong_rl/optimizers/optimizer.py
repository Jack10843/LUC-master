
class Optimizer:

    def __init__(self, sol_dim):
        self.sol_dim = sol_dim

    def optimize(self, *args, **kwargs):
        return
